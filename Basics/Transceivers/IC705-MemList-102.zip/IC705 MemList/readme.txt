          _____                 .____    .__          __ 
         /     \   ____   _____ |    |   |__| _______/  |_
        /  \ /  \_/ __ \ /     \|    |   |  |/  ___/\   __\
       /    Y    \  ___/|  Y Y  \    |___|  |\___ \  |  |
       \____|__  /\___  >__|_|  /_______ \__/____  > |__|
               \/     \/      \/        \/       \/  7.05


 DISCLAIMER:
 ===================================================================
 USE AT  YOUR OWN RISK! PLEASE SEE LICENSE FOR  FURTHER INFORMATION!


 Frequencies:
 ===================================================================
 Contains .CSV files  with  memory  channels  for  the  Icom CS-705
 software. In the software  create groups in the Memory CH section.
 Then use the  Import function (right mouse on group name)  to load
 a .CSV frequency file. Groups will be overwritten, so backup first.


 Scan Edges
 -------------------------------------------------------------------
 Contains a single .CSF file with popular  frequency ranges for the
 Icom CS-705 software. Click right on Program Scan Edge area in the
 software and choose  Import. Scan areas  will be  overwritten,  so
 backup first.

 
 73 de Arthur Konze, DL2ART
 ( •_•)O*¯`·.¸.·´¯`°Q(•_• )