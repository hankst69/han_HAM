﻿using System.Reflection;
using System.Runtime.Versioning;

[assembly: SupportedOSPlatform("windows7.0")]

[assembly: AssemblyTitle("Empty SDR# Plugin Project")]
[assembly: AssemblyProduct("SDR# Studio")]
[assembly: AssemblyCopyright("Copyright © Youssef Touil 2022")]
[assembly: AssemblyCompany("Airspy")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
