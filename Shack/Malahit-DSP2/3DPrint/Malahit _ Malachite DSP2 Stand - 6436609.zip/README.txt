Malahit / Malachite DSP2 Stand by Jinte on Thingiverse: https://www.thingiverse.com/thing:6436609

Summary:
A nice Stand for the Malahit DSP2.No support needed, no special print requirement.