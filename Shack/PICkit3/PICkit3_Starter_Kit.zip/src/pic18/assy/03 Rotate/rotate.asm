; *******************************************************************
; Lesson 3 - "Rotate"
;
; This lesson will introduce shifting instructions as well as bit-oriented skip operations to
; move the LED display.
;
; LEDs rotate from right to left at a rate of 1.5s
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302             ;supress the 'not in bank0' warning
    cblock 0x00                 ;shared memory location that is accessible from all banks
Delay1                          ;define two file registers for the delay loop in shared memory
Delay2
     endc

    ; -------------------LATC-----------------
    ; Bit#:  -7---6---5---4---3---2---1---0---
    ; LED:   ---------------|DS4|DS3|DS2|DS1|-
    ; -----------------------------------------

    ORG 0                       ;start of code at address 0x0000
Start:
     movlw      b'00100000'     ;set cpu clock speed of 500KHz
     movwf      OSCCON          ;move contents of the working register into OSCCON
     clrf       TRISC           ;make all of PORTC an output
     movlw      b'00001000'     ;start the rotation by setting DS4 ON
     movwf      LATC            ;write contents of the working register to the latch
MainLoop:
delayLoop:
     decfsz    Delay1,f         ;Waste time.
     bra       delayLoop        ;The Inner loop takes 3 instructions per loop * 256 loopss = 768 instructions
     decfsz    Delay2,f         ;The outer loop takes and additional 3 instructions per lap * 256 loops
     bra       delayLoop        ;(768+3) * 256 = 197376 instructions / 125K instructions per second = 1.579 sec.

Rotate:
    rrcf       LATC,f           ;rotate the LEDs (through carry) and turn on the next LED to the right
    btfss      STATUS,C         ;did the bit rotate into the carry (i.e. was DS1 just lit?)
    bra        MainLoop         ;nope, repeat this program forever
    bsf        LATC, 3          ;yes, it did and now start the sequence over again by turning on DS4
    bcf        STATUS, C        ;clear the carry
    bra        MainLoop         ;repeat this program forever

    end                         ;end code section