; *******************************************************************
; Lesson 12 - Table lookup
;
; This shows using a table lookup function to implement a
; binary to gray code conversion.  The POT is read by the A2D,
; The high order 4 bits then are converted to Gray Code and
; displayed on the LEDs.

; The Table Pointer is used to read a single byte in program memory
; The PC is also used to return a value in program memory
;
; Gray coded binary will be reflected on the LEDs in accordance with the POT reading
;
; PIC: 18F14K22
; Assembler: MPASM V5.43
; IDE: MPLABX v1.0
;
; Hardware: PICkit3 Low Pin Count Demo Board
; Date: 12.2011
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302      ;surpress the 'not in bank0' warning

;Only uncomment on of these!!
#define     __ClassicMethod
;#define     __TableRead


    cblock 0x00          
temp
     endc

     Org 0x00

Start:
    ;Setup main init
     movlw      b'00100010'     ;set cpu clock speed of 500KHz
     movwf      OSCCON          ;move contents of the working register into OSCCON


     ;Configure the LEDs
     clrf       TRISC           ;make all of PORTC an output
     clrf       LATC

     ;Configure the ADC/Potentimator
     bsf        TRISA,0         ;Potentimator is connected to RA0....set as input
     bsf        ANSEL, ANS0     ;analog input
     movlw      b'00000001'     ;select A0 as source of ADC and enable the module
     movwf      ADCON0
     movlw      b'00000001'     ;left justified - Fosc/8 speed
     movwf      ADCON2

     ;Clear the RAM
     clrf       temp

MainLoop:
    rcall        A2d             ;get the ADC result
    swapf       ADRESH, w       ;move the high nibble to wreg for LED display
    rcall        BinaryToGrayCode    ;convert to Grey Code (Note: important that this is CALLED and not BRANCHED to since
                                    ;the 'RETLW' instruction will return here with the conversion in wreg
    movwf       LATC            ;move grey code into LEDs
    bra         MainLoop        ;do this forever


A2d:
    ;Start the ADC
    nop                         ;requried ADC delay of 8uS => (1/(Fosc/4)) = (1/(500KHz/4)) = 8uS
    bsf         ADCON0, GO      ;start the ADC
    btfsc       ADCON0, GO      ;this bit will be cleared when the conversion is complete
    goto        $-2             ;keep checking the above line until GO bit is clear

    return

BinaryToGrayCode:
     andlw       0x0F               ; mask off invalid entries
     movwf       temp
#ifdef __ClassicMethod
     ;Using the Program Counter (PC) directly
     movlw      upper TableStart    ; move upper part
     movwf      PCLATU
     movlw     high TableStart     ; get high order part of the beginning of the table
     movwf     PCLATH
     movlw     low TableStart      ; load starting address of table
     rlcf      temp, f             ;multiply by 2 by shifting to the left (remember that the PIC18 has 16bit 	  program counter)
     addwf     temp,w              ; add offset from ADC conversion
     btfsc     STATUS,C            ; did it overflow?
     incf      PCLATH,f            ; yes: increment PCLATH
     movwf     PCL                 ; modify PCL
#endif
#ifdef __TableRead
    movlw       upper TableStart ; Load TBLPTR with the base
    movwf       TBLPTRU ; address of the word
    movlw       high TableStart
    movwf       TBLPTRH
    movlw       low TableStart
    rlcf        temp, f             ;multiply by 2 by shifting to the left 
    addwf       temp, w
    btfsc       STATUS, C
    incf        TBLPTRH , f
    movwf       TBLPTRL
READ_WORD:
    tblrd* ; read into TABLAT
    movf        TABLAT, w  ; get data
    return
#endif
     ;Use the PIC's program memory for values that do not change during runtime. This helps to conserve
     ;the RAM and is good programming practice
TableStart:
     retlw     b'0000'        ; 0
     retlw     b'0001'        ; 1
     retlw     b'0011'        ; 2
     retlw     b'0010'        ; 3
     retlw     b'0110'        ; 4
     retlw     b'0111'        ; 5
     retlw     b'0101'        ; 6
     retlw     b'0100'        ; 7
     retlw     b'1100'        ; 8
     retlw     b'1101'        ; 9
     retlw     b'1111'        ; 10
     retlw     b'1110'        ; 11
     retlw     b'1010'        ; 12
     retlw     b'1011'        ; 13
     retlw     b'1001'        ; 14
     retlw     b'1000'        ; 15

    end