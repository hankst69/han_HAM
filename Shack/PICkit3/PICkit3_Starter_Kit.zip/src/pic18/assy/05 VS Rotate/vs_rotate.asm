; *******************************************************************
; Lesson 5 - "Variable Speed Rotate"
;
; This lesson combines all of the previous lessons to produce a variable speed rotating
; LED display that is proportional to the ADC value. The ADC value and LED rotate
; speed are inversely proportional to each other.
;
; Rotate the POT counterclockwise to see the LEDs shift faster.
;
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302             ;supress the 'not in bank0' warning
    cblock 0x00                 ;shared memory location that is accessible from all banks
Delay1                          ;define two file registers for the delay loop in shared memory
Delay2
     endc


    ; -------------------LATC-----------------
    ; Bit#:  -7---6---5---4---3---2---1---0---
    ; LED:   ---------------|DS4|DS3|DS2|DS1|-
    ; -----------------------------------------

    ORG 0                       ;start of code
Start:
                                ;Setup main init
     movlw      b'00100010'     ;set cpu clock speed to 500KHz
     movwf      OSCCON          ;move contents of the working register into OSCCON

                                ;Configure the ADC/Potentimator
    bsf        TRISA,4          ;Potentimator is connected to RA4....set as input
    bsf        ANSEL, ANS3      ;analog input
    movlw      b'00001101'      ;select RA4 as source of ADC and enable the module
    movwf      ADCON0
    movlw      b'00000001'      ;left justified - Fosc/8 speed - vref is Vdd
    movwf      ADCON2

                                ;Configure the LEDs
     clrf       TRISC           ;make all of PORTC an output
     movlw      b'00001000'     ;start the rotation by setting DS4 ON
     movwf      LATC            ;write contents of the working register to the latch
MainLoop:
     rcall      A2d             ;get the ADC result
                                ;top 8 MSbs are now in the working register (Wreg)
     movwf      Delay2          ;move ADC result into the outer delay loop
     rcall      CheckIfZero     ;if ADC result is zero, load in a value of '1' or else the delay loop will decrement starting at 255
     rcall      DelayLoop       ;delay the next LED from turning ON
     rcall      Rotate          ;rotate the LEDs

     bra        MainLoop        ;do this forever

CheckIfZero:
     tstfsz     Delay2          ;if the ADC result is NOT '0', then simply return to MainLoop
     return                     ;return to MainLoop
     movlw      d'1'            ;ADC result IS '0'. Load delay routine with a '1' to avoid decrementing a rollunder value of 255
     movwf      Delay2          ;move it into the delay location in shared memory (RAM)
     return                     ;return to MainLoop
A2d:
                                ;Start the ADC

    nop                         ;requried ADC delay of 8uS => (1/(Fosc/4)) = (1/(500KHz/4)) = 8uS
    bsf         ADCON0, GO      ;start the ADC
    btfsc       ADCON0, GO      ;this bit will be cleared when the conversion is complete
    bra         $-2             ;keep checking the above line until GO bit is clear  :: NOTE: notice how it is $-2 and NOT $-1 like in the PIC16
    movf        ADRESH, w       ;Get the top 8 MSbs (remember that the ADC result is LEFT justified!)
    return      

DelayLoop:
                               ;Delay amount is determined by the value of the ADC

     decfsz     Delay1,f       ;will always be decrementing 255 here
     bra        DelayLoop      ;The Inner loop takes 3 instructions per loop * 255 loops (required delay)
     decfsz     Delay2,f       ;The outer loop takes and additional 3 instructions per lap * X loops (X = top 8 MSbs from ADC conversion)
     bra        DelayLoop

     return

Rotate:
    rrcf        LATC,f          ;rotate the LEDs (through carry) and turn on the next LED to the right
    btfss       STATUS,C        ;did the bit rotate into the carry (i.e. was DS1 just lit?)
    bra         MainLoop        ;nope, repeat this program forever
    bsf         LATC, 3         ;yes, it did and now start the sequence over again by turning on DS4
    bcf         STATUS, C       ;clear the carry
    bra         MainLoop        ;repeat this program forever

    end                         ;end code section