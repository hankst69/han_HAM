; *******************************************************************
; Lesson 10 - Interrupts and Pull-ups
;
; This lesson will introduce interrupts and how they are useful. It will
; also introduce internal weak pull-ups that are available on most PICs.
;
; It should be noted that this lesson is more efficent than the last
; one, "Timer0". Notice how the processor is no longer waiting for
; Timer0 to roll over. Instead, we let the hardware modules do the work,
; freeing the CPU to do other things in the main loop
;
; The switch is no longer continuously polled for a button press. Instead,
; an interrupt will occur which will automically place the program counter
; inside of the ISR where we can change directions outisde of normal code execution
;
; LEDs rotate at a constant speed and the switch reverses their direction
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302                 ;surpress the 'not in bank0' warning

#define         DOWN        0x00    ;when SW1 is pressed, the voltage is pulled down through R3 to ground (GND)
#define         UP          0xFF     ;when SW1 is not pressed, the voltage is pulled up through R1 to Power (Vdd)
#define         SWITCH      PORTA, 2 ;pin where SW1 is connected..NOTE: always READ from the PORT and WRITE to the LATCH

#define         PULL_UPS            ;if this is uncommented, then the trace under JP5 can be cut with no adverse affects

#define         LED_RIGHT   0xFF       ;keep track of LED direction
#define         LED_LEFT    0x00

    cblock 0x00
Delay1                              ;for debounce delay
Direction                           ;either 1 or 0 depending on what direction LEDs are going
Previous_Direction                  ;don't keep toggling the direction if the switch is held down
     endc

     Org 0x0000                     ;Reset Vector starts at 0x0000
     bra        Start               ;main code execution

     Org 0x0008                     ;High Priority Interrupt Vector starts at address 0x0008
     bra        ISR
     
Start:
                                    ;Setup main init
     movlw      b'00100010'         ;set cpu clock speed to 500KHz
     movwf      OSCCON              ;move contents of the working register into OSCCON

                                    ;Setup SW1 as input
     bcf        ANSEL, ANS2         ;digital
     bsf        TRISA, RA2          ;input

#ifdef PULL_UPS
     bsf        WPUA, RA2           ;enable the weak pull-up for the switch
     bcf        INTCON2, NOT_RABPU  ;enable the global weak pull-up bit
#endif                              ;this bit is active HIGH, meaning it must be cleared for it to be enabled


                                    ;Configure the LEDs
     clrf       TRISC               ;make all of PORTC an output
     clrf       LATC
     bsf        LATC, 3             ;start with DS4 ON

                                    ;Setup Timer0
     movlw      b'01000111'         ;1:256 prescaler for a delay of: (insruction-cycle * 256-counts)*prescaler = ((8uS * 256)*256) =~ 524mS
     movwf      T0CON               ;configured as 8-bit timer
     bsf        T0CON, TMR0ON       ;turn on TMR0
     bsf        INTCON, TMR0IE      ;enable interrupt when TMR0 overflows

                                    ;Setup interrupt-on-change for the switch
     bsf        INTCON, RABIE       ;must set this global enable flag to allow any interrupt-on-change flags to cuase an interrupt
     bsf        IOCA,  IOCA2        ;when SW1 is pressed, enter the ISR (Note, this is set when a FALLING EDGE is detected)
     bcf        RCON, IPEN          ;no priority interrupts
     bsf        INTCON, GIE         ;must set this global to allow any interrupt to bring the program into the ISR
                                    ;if this is not set, the interrupt flags will still get set, but the ISR will never be entered

     movlw      LED_RIGHT           ;start with LEDs shifting to the right
     movwf      Direction
                                    ;Clear the RAM          
     clrf       Previous_Direction
     clrf       Delay1

MainLoop:
    bra         MainLoop            ;can spend rest of time doing something critical here


Debounce:
    btfsc       SWITCH              ;check if switch is down
    bra         SwitchNotDown
                                    ;delay for approximatly 5ms
    movlw       d'209'              ;(1/(500KHz/4))*209*3 = 5.016mS
    movwf       Delay1
DebounceLoop:
    decfsz      Delay1, f           ;1 instruction to decrement,unless if branching (ie Delay1 = 0)
    bra         DebounceLoop        ;2 instructions to branch

    btfsc       SWITCH              ;check if switch is still down.
    bra         SwitchNotDown       ;failed the debounce test
ToggleDirection:                    ;switch is still down, toggle LED direction if previous direction != current direction
    movlw       DOWN                 ;load wreg with '0'
    subwf       Previous_Direction, w  ;exit if SW1 was previously held down
    btfsc       STATUS, Z
    return                          ;exit with no toggling of LED direction

    movlw       0xFF                ;get here if button was just pressed
    xorwf       Direction, f        ;toggle direction states by using the XOR instruction and saving in RAM
    movlw       DOWN
    movwf       Previous_Direction  ;don't enter here again until switch is released and then pressed again
    return
SwitchNotDown:
    movlw       UP
    movwf       Previous_Direction
    return                          ;return back to the MainLoop where 'Debounce' was called


                                    ;Clearing the carry before rotating through the carry is essentailly an equivalent
                                    ;of a logic shift (lslf) equivalent like in the PIC161829 example
RotateRight:
    bcf         STATUS, C           ;clear the carry
    rrcf        LATC,f              ;rotate the LEDs (through carry) and turn on the next LED to the right
    btfss       STATUS,C            ;did the bit rotate into the carry (i.e. was DS1 just lit?)
    retfie
    bsf         LATC, 3             ;yes, it did and now start the sequence over again by turning on DS4
    bcf         STATUS, C           ;clear the carry
    retfie
RotateLeft:
    rlncf       LATC, f             ;rotate the LEDs (no carry) and turn on the next LED to the left
    btfsc       LATC, 4             ;did it rotate out of the LED display?
    bsf         LATC, 0             ;yes, put in bit 0
    retfie

                                    ;Enter here if an interrupt has occured
                                    ;First, check what caused the interrupt by checking the ISR flags
                                    ;This lesson only has 2 flags to check
ISR:
    btfsc       INTCON, RABIF       ;check if switch was just pressed/pressed
    bra         Service_SW1         ;yes, lets service it
    bra         Service_TMR0        ;nope, TMR0 just overflowed

                                    ;The PIC18F14K22 does not have rising/falling edge detection
                                    ;extra software is needed to check if it is falling edge
                                    ;if this extra routine is ommitted, a quick press of the switch
                                    ;will cause the LEDs to not change directions at all since both edges will
                                    ;be detected (rising & falling). If the switch is held, a release
                                    ;of the switch will cause the LEDs to change directions yet again.
Service_SW1:
    bcf         INTCON, RABIF       ;MUST ALWAYS clear this in software or else stuck in the ISR forever
    rcall       Debounce            ;delay for 5ms and then check the switch again
    retfie  
Service_TMR0:
    bcf         INTCON, T0IF        ;MUST ALWAYS clear this in software or else stuck in the ISR forever
    tstfsz      Direction           ;check what direction currently in
    bra         RotateRight
    bra         RotateLeft

    end