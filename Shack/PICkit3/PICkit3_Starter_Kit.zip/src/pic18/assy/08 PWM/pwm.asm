; *******************************************************************
; Lesson 8 - PWM
;
; Pulse-Width Modulation (PWM) is a scheme that provides power to a load by switching
; quickly between fully on and fully off states. The PWM signal resembles a square wave
; where the high portion of the signal is considered the on state and the low portion of
; the signal is considered the off state. The high portion, also known as the pulse width,
; can vary in time and is defined in steps. A longer, high on time will illuminate the LED
; brighter. The frequency or period of the PWM does not change. A larger number of
; steps applied, which lengthens the pulse width, also supplies more power to the load.
; Lowering the number of steps applied, which shortens the pulse width, supplies less
; power. The PWM period is defined as the duration of one complete cycle or the total
; amount of on and off time combined.
;
; Rotating the POT will adjust the brightness of a single LED.
;
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

     errorlevel -302            ;surpress the 'not in bank0' warning

     Org 0
Start:
                                ;Setup main init
     movlw      b'00100010'     ;set cpu clock speed to 500KHz
     movwf      OSCCON          ;move contents of the working register into OSCCON

                                ;Configure the LEDs
     clrf       TRISC           ;make all of PORTC an output
     clrf       LATC

                                ;Configure the ADC/Potentimator
     bsf        TRISA, 4        ;Potentimator is connected to RA4....set as input
     bsf        ANSEL, ANS3     ;analog input
     movlw      b'00001101'     ;select A0 as source of ADC and enable the module
     movwf      ADCON0
     movlw      b'00000001'     ;left justified - Fosc/8 speed - vref is Vdd
     movwf      ADCON2

                                ;Configure the PWM module
     movlw      b'01001100'     ;PWM mode - Full bridge - modulate DS3
     movwf      CCP1CON
            
     movlw      0xFF            ;Frequency at 488Hz. Anything over ~60Hz will get rid of any flicker
     movwf      PR2             ;PWM Period = [PR2 + 1]*4*Tosc*T2CKPS = [255 + 1] * 4 * (1 / 500KHz) * 1
     clrf       T2CON           ;1:1 postscaler and 1 prescaler
     bsf        T2CON, TMR2ON   ;start the PWM by setting TMR2ON bit
MainLoop:
     rcall      A2d             ;begin the Analog to Digital conversion

                                ;ADRESH and ADRESL are now both full of the ADC result!

     movf        ADRESH, w      ;Get the top 8 MSbs (remember that the ADC result is LEFT justified!)
     movwf       CCPR1L
    
                                ;to fill the 10bit PWM registers, these 2 LSBS will be put into the
                                ;Duty Cycle Bits (DC2B) of the CCP2CON register which are bits 5 and 4.
                                ;So we need to shift these LSB into place and OR them with CCP2CON
                                ;in order to save the settings above and fill these last bits in
                                ;ADRESL =  b'xx000000' where 'xx' are the 2 LSBs from the ADC result
    rrncf       ADRESL, f       ;ADRESL = b'0xx00000'
    rrncf       ADRESL, f       ;ADRESL = b'00xx0000'
    movf        ADRESL, w       ;now move into wreg
	
                                ;move the 2 LSBs into place without disturbing the rest of CCP2CON settings
    xorwf       CCP1CON, w	;clears bits that are the same and sets bits that are different.
    andlw       B'00110000'	;clears all control bits in WREG so they don't change in the final step
    xorwf       CCP1CON, f      ;changes bits that changed and leaves everything else untouched.

    bra         MainLoop        ;do this forever


A2d:
                                ;Start the ADC
    nop                         ;requried ADC delay of 8uS => (1/(Fosc/4)) = (1/(500KHz/4)) = 8uS
    bsf         ADCON0, GO      ;start the ADC
    btfsc       ADCON0, GO      ;this bit will be cleared when the conversion is complete
    goto        $-2             ;keep checking the above line until GO bit is clear

    return

    end