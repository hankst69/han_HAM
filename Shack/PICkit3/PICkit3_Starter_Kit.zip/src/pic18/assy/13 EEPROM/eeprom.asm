; *******************************************************************
; Lesson 13 - EEPROM
;
; This lesson will provide code for writing and reading a single byte onto
; the on-board EEPROM. EEPROM is non-volatile memory, meaning that it does
; not lose its value when power is shut off. This is unlike RAM, which will
; lose its value when no power is applied. The EEPROM is useful for storing
; variables that must still be present during no power.
; It is also convenient to use if the entire RAM space is used up.
; Writes and reads to the EEPROM are practically instant and are much faster
; than program memory operations.

; Press the switch to save the LED state and then disconnect the power. When
; power is then applied again, the program will start with that same LED lit.

; When the lesson is first programmed, no LEDs will light up even with movement
; of the POT. When the switch is pressed, the corresponding LED will be lit and
; then the PIC will go to sleep until the switch is pressed again. Each press of
; the switch saves the ADC value into EEPROM. The PIC uses interrupts to wake up
; from sleep, take an ADC reading, save to EEPROM, and then goes back to sleep.

;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302                     ;surpress the 'not in bank0' warning

#define         DOWN    0x00            ;when SW1 is pressed, the voltage is pulled down through R3 to ground (GND)
#define         UP      0xFF            ;when SW1 is not pressed, the voltage is pulled up through R1 to Power (Vdd)
#define         EEPROM_ADDR 0x00        ;read from the start of EEPROM where the ADC value will be saved
#define         SWITCH  PORTA, 2        ;pin where SW1 is connected..NOTE: always READ from the PORT and WRITE to the LATCH

    cblock 0x00
Delay1                                  ;for debounce delay
     endc

     Org 0x0000                         ;Reset Vector starts at 0x0000
     bra        Start                   ;main code execution

     Org 0x0008                         ;High Priority Interrupt Vector starts at address 0x0008
     goto        ISR
Start:
                                        ;Setup main init
     movlw      b'00100010'             ;set cpu clock speed of 500KHz
     movwf      OSCCON
                                        ;Setup SW1 as input
     bcf        ANSEL, ANS2             ;digital
     bsf        TRISA, RA2              ;input

                                        ;Configure the ADC/Potentimator
     bsf        TRISA,4                 ;Potentimator is connected to RA4....set as input
     bsf        ANSEL, ANS3             ;analog input
     movlw      b'00001101'             ;select RA4 as source of ADC and enable the module
     movwf      ADCON0
     movlw      b'00000001'             ;left justified - Fosc/8 speed - vref is Vdd
     movwf      ADCON2

                                        ;Setup IOC (Interrupt on change)
     bsf        INTCON, RABIE           ;must set this global enable flag to allow any interrupt-on-change flags to cuase an interrupt
     bsf        IOCA,  IOCA2            ;when SW1 is pressed, enter the ISR (Note, this is set when a FALLING EDGE is detected)
     bcf        RCON, IPEN              ;no priority interrupts
     bsf        INTCON, GIE             ;must set this global to allow any interrupt to bring the program into the ISR
                                        ;if this is not set, the interrupt flags will still get set, but the ISR will never be entered
                                        ;Configure the LEDs
     clrf       TRISC                   ;make all of PORTC an output
     clrf       LATC                    ;write contents of the working register to the latch

    movlw       EEPROM_ADDR             ;read from the first byte where the previous ADC value was saved
    rcall       EERead                  ;read the first byte of EEPROM
    movwf       LATC                    ;move ADC result into the LEDs
MainLoop:
    SLEEP                               ;sleep until SW1 is pressed/released
                                        ;The PIC will wake up and immediately enter the ISR when RABIF
                                        ;is set. This will happen with either a rising or falling edge is
                                        ;detected on RA3, or rather SW1
    bra         MainLoop


EERead:
    movwf       EEADR
    bcf         EECON1, EEPGD           ;point to DATA memory
    bcf         EECON1, CFGS            ;access EEPROM
    bsf         EECON1, RD              ;EEPROM read
    movf        EEDATA, w               ;save in wreg
    return                              ;return to MainLoop with answer in wreg

A2d:
                                        ;Start the ADC
    nop                                 ;requried ADC delay of 8uS => (1/(Fosc/4)) = (1/(500KHz/4)) = 8uS
    bsf         ADCON0, GO              ;start the ADC
    btfsc       ADCON0, GO              ;this bit will be cleared when the conversion is complete
    goto        $-2                     ;keep checking the above line until GO bit is clear  :: NOTE: notice how it is $-2 and NOT $-1 like in the PIC16
    swapf       ADRESH, w               ;only save the high nibble
    return
Debounce:
                                        ;delay for approximatly 5ms
    movlw       d'209'                  ;(1/(500KHz/4))*209*3 = 5.016mS
    movwf       Delay1
DebounceLoop:
    decfsz      Delay1, f               ;1 instruction to decrement,unless if branching (ie Delay1 = 0)
    bra         DebounceLoop            ;2 instructions to branch

    btfsc       SWITCH                  ;check if switch is still down.
    retfie                              ;exit without doing anything
    rcall        A2d                    ;Get here if switch is still held down - get the current ADC value
    movwf       LATC                    ;display result on the LEDs

                                        ;Writes one byte to EEPROM at EEPROM_ADDR
EEWrite:                        
    movwf       EEDATA                  ;move the ADC result into EEDATA (previously saved in wreg)
    movlw       EEPROM_ADDR             ;move the address into wreg
    movwf       EEADR                   ;indicates where to write
    bcf         EECON1, EEPGD           ;point to DATA memory
    bcf         EECON1, CFGS            ;access EEPROM
    bsf         EECON1, WREN            ;enable writes
    bcf         INTCON, GIE             ;ALWAYS disable interrupts before writting to EEPROM!!
                                        ;NOTE: While inside the ISR, GIE will be cleared in hardware automatically, so the above line is not
                                        ;necessary, although it is good practice to always do this anyways. GIE will be set in hardware when
                                        ;the ISR is exited

                                        ;REQUIRED SEQUENCE
    movlw       0x55
    movwf       EECON2
    movlw       0xAA
    movwf       EECON2
    bsf         EECON1, WR              ;begin write

                                        ;END REQUIRED SEQUENCE
    bcf         EECON1, WREN            ;disable writes
    btfsc       EECON1, WR              ;wait for write to be complete
    bra         $-2
    bsf         INTCON, GIE             ;re-enable interrupts

    return                              ;return to 'Service_SW1' label after the Debounce call


ISR:
    btfsc       INTCON, RABIF           ;was switch just pressed/pressed?
    bra         Service_SW1             ;yes, lets service it
    retfie                              ;nope, exit ISR
Service_SW1:
    bcf         INTCON, RABIF           ;MUST ALWAYS clear this in software or else stuck in the ISR forever
    rcall       Debounce                ;delay for 5ms and then check the switch again
    retfie 

    end                                 ;end code