; *******************************************************************
; Lesson 2 - "Hello World"
;
; One way to create a delay is to spend time decrementing a value. In assembly, the timing
; can be accurately programmed since the user will have direct control on how the
; code is executed. In �C�, the compiler takes the �C� and compiles it into assembly before
; creating the file to program to the actual PIC MCU (HEX file). Because of this, it is hard
; to predict exactly how many instructions it takes for a line of �C� to execute.
;
;
; DS1 blinks at a rate of approximately 1.5 seconds.
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRCCLKOUT, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302             ;supress the 'not in bank0' warning
    cblock 0x00                 ;Access RAM
Delay1                          ; Define two file registers for the delay loop in shared memory
Delay2         
     endc

    ORG 0
Start: 
     movlw      b'00101000'     ;set cpu clock speed of 500KHz
     movwf      OSCCON
     bcf        TRISC,0         ;make IO Pin C0 an output (DS1)
     clrf       LATC            ;int the LEDs to zero

MainLoop:
     decfsz     Delay1,f        ;Waste time.
     bra        MainLoop        ;The Inner loop takes 3 instructions per loop * 256 loops = 768 instructions
     decfsz     Delay2,f        ;The outer loop takes an additional 3 instructions per lap * 256 loops
     bra        MainLoop        ;(768+3) * 256 = 197376 instructions / 125K instructions per second = 1.579 sec.
     btg        LATC,0          ;toggle DS1
     bra        MainLoop        ;do this forever

     end                        ;end code section