; *******************************************************************
; Lesson 1 - "Hello World"
;
; The LEDs are connected to input-outpins (I/O) RC0 through RC3. First, the I/O pin
; must be configured for an output. In this case, when one of these pins is driven high
; (RC0 =  1 ), the LED will turn on. These two logic levels are derived from the power pins
; of the PIC MCU. Since the PIC device�s power pin (VDD) is connected to 5V and the
; source (VSS) to ground (0V), a � 1 � is equivalent to 5V, and a �0 � is 0V.
;
;
; This turns on DS1 LED on the Low Pin Count Demo Board.
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
; 
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings 
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

    errorlevel -302         ;supress the 'not in bank0' warning

    ORG 0
Start:
     bcf     TRISC,0        ;make IO Pin C0 an output
     clrf    LATC           ;init the LATCH by turning off everything
     bsf     LATC,0         ;turn on LED C0 (DS1)
     goto    $              ;sit here forever!

    end