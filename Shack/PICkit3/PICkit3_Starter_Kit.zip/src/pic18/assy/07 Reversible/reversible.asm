; *******************************************************************
; Lesson 7 - Reversible Variable Speed Rotate
;
; LEDs will rotate at a speed that is proportional to the ADC value. The switch will toggle
; the direction of the LEDs
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

    ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

#define     DOWN    0x00              ;when SW1 is pressed, the voltage is pulled down through R3 to ground (GND)
#define     UP      0xFF              ;when SW1 is not pressed, the voltage is pulled up through R1 to Power (Vdd)
#define     SWITCH  PORTA, 2          ;pin where SW1 is connected..NOTE: always READ from the PORT and WRITE to the LATCH

#define     LED_RIGHT   0xFF             ;keep track of LED direction
#define     LED_LEFT    0x00

    errorlevel -302      ;surpress the 'not in bank0' warning

    ; -------------------LATC-----------------
    ; Bit#:  -7---6---5---4---3---2---1---0---
    ; LED:   ---------------|DS4|DS3|DS2|DS1|-
    ; -----------------------------------------

    cblock 0x00                     ;shared memory location that is accessible from all banks
Delay1                              ;delay loop for debounce and LED delay
Delay2                              ;delay loop for LED delay
Direction                           ;either 1 or 0 depending on what direction LEDs are going
Previous_Direction                  ;don't keep toggling the direction if the switch is held down
     endc

     ORG 0                          ;start of code
Start:
                                    ;Setup main init
    movlw       b'00100010'         ;set cpu clock speed of 500KHz
    movwf       OSCCON

                                    ;Setup SW1 as input
    bcf         ANSEL, ANS2         ;digital
    bsf         TRISA, RA2          ;input

                                    ;Configure the LEDs
    clrf        TRISC               ;make all of PORTC an output
    movlw       b'00001000'         ;start with  DS1 ON
    movwf       LATC

                                    ;Configure the ADC/Potentimator
    bsf         TRISA,4             ;Potentimator is connected to RA4....set as input
    bsf         ANSEL, ANS3         ;analog input
    movlw       b'00001101'         ;select A0 as source of ADC and enable the module
    movwf       ADCON0
    movlw       b'00000001'         ;left justified - Fosc/8 speed - vref is Vdd
    movwf       ADCON2

    movlw       LED_RIGHT           ;start with LEDs shifting to the right
    movwf       Direction
                                    ;Clear the RAM
    clrf        Previous_Direction
    clrf        Delay1
    clrf        Delay2

MainLoop:

     rcall      A2d                 ;get the ADC result
                                    ;top 8 MSBs are now in the working register (Wreg)
     movwf      Delay2              ;move ADC result into the outer delay loop
     rcall      CheckIfZero         ;if ADC result is zero, load in a value of '1' or else the delay loop will decrement starting at 255
     rcall      DelayLoop           ;delay the next LED from turning ON
     rcall      Debounce            ;check if SW1 was pressed
     rcall      Rotate              ;rotate the LEDs

     bra        MainLoop            ;do this forever


Debounce:
    btfsc       SWITCH              ;check if switch is down
    bra         SwitchNotDown
                                    ;delay for approximatly 5ms
    movlw       d'209'              ;(1/(500KHz/4))*209*3 = 5.016mS
    movwf       Delay1
DebounceLoop:
    decfsz      Delay1, f           ;1 instruction to decrement,unless if branching (ie Delay1 = 0)
    bra         DebounceLoop        ;2 instructions to branch

    btfsc       SWITCH              ;check if switch is still down.
    bra         SwitchNotDown       ;failed the debounce test
ToggleDirection:                    ;switch is still down, toggle LED direction if previous direction != current direction
    movlw       DOWN                 ;load wreg with '0'
    subwf       Previous_Direction, w;exit if SW1 was held down
    btfsc       STATUS, Z
    return                          ;exit with no toggling of LED direction

    movlw       0xFF                ;get here if button was just pressed
    xorwf       Direction, f        ;toggle direction states by using the XOR instruction and saving in RAM
    movlw       DOWN
    movwf       Previous_Direction  ;don't enter here again until switch is released and then pressed again
    return
SwitchNotDown:
    movlw       UP
    movwf       Previous_Direction
    return                          ;return back to the MainLoop where 'Debounce' was called

CheckIfZero:
    tstfsz      Delay2              ;if the ADC result is NOT '0', then simply return to MainLoop
    return                          ;return to MainLoop
    movlw       d'1'                ;ADC result IS '0'. Load delay routine with a '1' to avoid decrementing a rollover value of 255
    movwf       Delay2              ;move it into the delay location in shared memory (RAM)
    return                          ;return to MainLoop

A2d:                                ;Start the ADC
    nop                             ;requried ADC delay of 8uS => (1/(Fosc/4)) = (1/(500KHz/4)) = 8uS
    bsf         ADCON0, GO          ;start the ADC
    btfsc       ADCON0, GO          ;this bit will be cleared when the conversion is complete
    bra         $-2                 ;keep checking the above line until GO bit is clear  :: NOTE: notice how it is $-2 and NOT $-1 like in the PIC16
    movf        ADRESH, w           ;Get the top 8 MSBs (remember that the ADC result is LEFT justified!)

    return

DelayLoop:
                                    ;Delay amount is determined by the value of the ADC
     decfsz    Delay1,f             ;will always be decrementing 255 here
     bra       DelayLoop            ;The Inner loop takes 3 instructions per loop * 255 loops (required delay)
     decfsz    Delay2,f             ;The outer loop takes and additional 3 instructions per lap * X loops (X = top 8 MSBs from ADC conversion)
     bra       DelayLoop

     return

Rotate:
     tstfsz    Direction           ;check what direction currently in - takes advantage of the fact that #define LED_RIGHT == 0
     bra       RotateRight
     bra       RotateLeft


                                    ;Clearing the carry before rotating through the carry is essentailly an equivalent
                                    ;of a logic shift (lslf) equivalent like in the PIC161829 example
RotateRight:
    bcf        STATUS, C            ;clear the carry
    rrcf       LATC,f               ;rotate the LEDs (through carry) and turn on the next LED to the right
    btfss      STATUS,C             ;did the bit rotate into the carry (i.e. was DS1 just lit?)
    bra        MainLoop
    bsf        LATC, 3              ;yes, it did and now start the sequence over again by turning on DS4
    bcf        STATUS, C            ;clear the carry
    bra        MainLoop             ;repeat this program forever
RotateLeft:
    rlncf      LATC, f              ;rotate the LEDs (no carry) and turn on the next LED to the left
    btfsc      LATC, 4              ;did it rotate out of the LED display?
    bsf        LATC, 0              ;yes, put in bit 0
    bra        MainLoop

    end                             ;end code