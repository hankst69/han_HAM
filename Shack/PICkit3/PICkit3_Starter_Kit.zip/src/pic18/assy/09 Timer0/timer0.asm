; *******************************************************************
; Lesson 9 - Timer0
;
; Timer0 is a counter implemented in the processor. It may be used to count instruction 
; cycles or external events, that occur at or below the instruction cycle rate.
; In the PIC18, Timer0 can be used as either an 8-bit or 16-bit counter, or timer. The 
; enhanced mid-range core implements only an 8-bit counter.
; This lesson configures Timer0 to count instruction cycles and to set a flag when it rolls 
; over. This frees up the processor to do meaningful work rather than wasting instruction 
; cycles in a timing loop. 
; Using a counter provides a convenient method of measuring time or delay loops as it 
; allows the processor to work on other tasks rather than counting instruction cycles. 
;
; LEDs rotate from right to left, similar to Lesson 3, at a rate of ~.5 second.
;
; PIC: 18F14K22
; Compiler: MPASM v5.43
; IDE: MPLABX v1.10
;
; Board: PICkit 3 Low Pin Count Demo Board
; Date: 6.1.2012
;
; *******************************************************************
; * See Low Pin Count Demo Board User's Guide for Lesson Information*
; *******************************************************************

#include <p18F14K22.inc>

                                ;Config settings
    CONFIG IESO = OFF, PLLEN = OFF, FOSC = IRC, FCMEN = OFF, PCLKEN = OFF
    CONFIG BOREN = SBORDIS, BORV = 19, PWRTEN = OFF, WDTEN = OFF
    CONFIG MCLRE = OFF, HFOFST = OFF, DEBUG = OFF, STVREN = ON
    CONFIG XINST = OFF, BBSIZ = OFF, LVP = OFF
    CONFIG CP0 = OFF, CP1 = OFF
    CONFIG CPD = OFF, CPB = OFF
    CONFIG WRT0 = OFF, WRT1 = OFF
    CONFIG WRTB = OFF, WRTC = OFF, WRTD = OFF
    CONFIG EBTR0 = OFF, EBTR1 = OFF
    CONFIG EBTRB = OFF

     errorlevel -302            ;surpress the 'not in bank0' warning

     Org 0
Start:
                                ;Setup main init
     movlw      b'00100010'     ;set cpu clock speed to 500KHz
     movwf      OSCCON          ;move contents of the working register into OSCCON

                                ;Configure the LEDs
     clrf       TRISC           ;make all of PORTC an output
     movlw      b'00001000'     ;start with DS4 lit
     movwf      LATC

                                ;Setup Timer0
     movlw      b'01000111'     ;1:256 prescaler for a delay of: (insruction-cycle * 256-counts)*prescaler = ((8uS * 256)*256) =~ 524mS
     movwf      T0CON           ; configured as 8-bit timer
     bsf        T0CON, TMR0ON   ;turn on TMR0

MainLoop:
    btfss       INTCON, TMR0IF  ;did TMR0 roll over yet?
    bra         $-2             ;no, wait until TMR0 overflows and sets TMR0IF
    bcf         INTCON, TMR0IF  ;yes, must clear flag in software

                                ;rotate the LEDs
    rrcf        LATC, f
    btfss       STATUS, C       ;did the bit rotate into the carry?
    bra         MainLoop        ;no, continue forever
    bsf         LATC, 3         ;yes, put light DS4 
    bcf         STATUS, C       ;clear the carry bit
    bra         MainLoop        ;continue forever

    

    end
