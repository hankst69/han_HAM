Manual install
==============

1. Copy both the SDRunoPlugin_ADSB.dll and ADSBPluginHelp.pdf files into your SDRuno Community Plugins folder
2. Copy public_html folder to the C:\ProgramData\SDRplay (create the SDRplay folder if it doesn't exist)

The public_html folder must appear as C:\ProgramData\SDRplay\public_html for the local website function of the plugin to work.