This directory contains flag icons for use to display country flags in the DUMP1090 web interface.

Country flag functionality submitted by Dino Moriello

The flags are supplied by
Free Country Flags by Gang of the Coconuts and is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.

Free Country Flags: 
http://www.free-country-flags.com/

Creative Commons Attribution-ShareAlike 3.0 Unported License
http://creativecommons.org/licenses/by-sa/3.0/
